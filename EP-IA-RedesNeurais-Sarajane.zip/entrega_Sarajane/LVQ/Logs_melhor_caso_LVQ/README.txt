Esses s�o os logs para o melhor neur�nio encontrado.
Levando em conta que a inicializa��o dele � feito via primeira Entrada.